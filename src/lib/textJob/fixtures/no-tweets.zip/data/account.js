window.YTD.account.part0 = [
  {
    "account": {
      "username": "fixturehandle",
      "accountDisplayName": "Fixture Handle",
      "createdAt": "Mon Jan 01 00:00:00 +0000 2020"
    }
  }
];
