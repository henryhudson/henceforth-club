window.YTD.tweets.part0 = [
  {
    "tweet": {
      "id_str": "2000000000000000000",
      "created_at": "Mon Jan 01 12:00:00 +0000 2024",
      "full_text": "Post number 0 in the oversize fixture, padded with enough text that the serialized archive clears any small byte budget a test hands it."
    }
  },
  {
    "tweet": {
      "id_str": "2000000000000000001",
      "created_at": "Mon Jan 01 12:00:00 +0000 2024",
      "full_text": "Post number 1 in the oversize fixture, padded with enough text that the serialized archive clears any small byte budget a test hands it."
    }
  },
  {
    "tweet": {
      "id_str": "2000000000000000002",
      "created_at": "Mon Jan 01 12:00:00 +0000 2024",
      "full_text": "Post number 2 in the oversize fixture, padded with enough text that the serialized archive clears any small byte budget a test hands it."
    }
  },
  {
    "tweet": {
      "id_str": "2000000000000000003",
      "created_at": "Mon Jan 01 12:00:00 +0000 2024",
      "full_text": "Post number 3 in the oversize fixture, padded with enough text that the serialized archive clears any small byte budget a test hands it."
    }
  },
  {
    "tweet": {
      "id_str": "2000000000000000004",
      "created_at": "Mon Jan 01 12:00:00 +0000 2024",
      "full_text": "Post number 4 in the oversize fixture, padded with enough text that the serialized archive clears any small byte budget a test hands it."
    }
  }
];
