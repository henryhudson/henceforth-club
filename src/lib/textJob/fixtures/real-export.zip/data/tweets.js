window.YTD.tweets.part0 = [
  {
    "tweet": {
      "id_str": "1000000000000000001",
      "created_at": "Mon Jan 01 12:00:00 +0000 2024",
      "full_text": "First real post from the miniature fixture archive."
    }
  },
  {
    "tweet": {
      "id_str": "1000000000000000002",
      "created_at": "Tue Jan 02 09:30:00 +0000 2024",
      "full_text": "Second post, replying to nobody in particular."
    }
  },
  {
    "tweet": {
      "id_str": "1000000000000000003",
      "created_at": "Wed Jan 03 18:45:00 +0000 2024",
      "full_text": "Third and final post in the fixture."
    }
  }
];
